#include "types.h"
#include "x86.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "mmu.h"
#include "proc.h"

int
sys_fork(void)
{
  return fork();
}

int
sys_exit(void)
{
  exit();
  return 0;  // not reached
}

int
sys_wait(void)
{
  return wait();
}

int
sys_kill(void)
{
  int pid;

  if(argint(0, &pid) < 0)
    return -1;
  return kill(pid);
}

int
sys_getpid(void)
{
  return proc->pid;
}

int
sys_sbrk(void)
{
  int addr;
  int n;

  if(argint(0, &n) < 0)
    return -1;
  addr = proc->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

int
sys_sleep(void)
{
  int n;
  uint ticks0;
  
  if(argint(0, &n) < 0)
    return -1;
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(proc->killed){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

// return how many clock tick interrupts have occurred
// since start.
int
sys_uptime(void)
{
  uint xticks;
  
  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}
int sys_lseek(void) {
	int fd;
	int old;
	int seek;
	int new;
	int cnt = 0;
	int i;
	char *ptr;

	struct file *file;

	argfd(0, &fd, &file);
	argint(1, &old);
	argint(2, &seek);

	if(seek == SEEK_SET) {
		new = old;
	}

	if (seek == SEEK_CUR)
		new = file->off + old;

	if (seek == SEEK_END)
		new = file->ip->size + old;
	if (new < file->ip->size)
		return -1;

	if (new > file->ip->size){
		cnt = new - file->ip->size;
		ptr = kalloc();
		while (cnt > 0){
			filewrite(file, ptr, cnt);
			cnt -= 4096;
		}
		kfree(ptr);
	}

	file->off = new;
	return 0;
}

