#include "types.h"
#include "user.h"

int main(){
	printf(1, "foo\n");
	exit();
}
